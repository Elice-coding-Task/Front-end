const slides = document.querySelectorAll('#slides > img');
const next = document.getElementById('next');
const prev = document.getElementById('prev');

//현재 이미지 파일의 인덱스 번호 
let current = 0;

showSlides(current);

prev.onclick = prevSlide;
// prev.addEventListener('click', () => {
//   prevSlide();
//   //추가로 다른 함수 실행 가능  
// });
next.onclick = nextSlide;
// next.addEventListener('click', () => {
//     nextSlide();
//     //추가로 다른 함수 실행 가능
// });

function showSlides (n) {
    //이미지의 display를 모두 none으로 설정(초기화)
    for(let i = 0; i < slides.length ; i ++) {
        slides[i].style.display = "none";
    };
    //해당하는 이미지만 display를 block으로 설정
    slides[n].style.display = "block";
}

function prevSlide () {
    // current가 0보다 크면 전 인덱스로 0일 때는 이미지 마지막 인덱스로 설정
    current > 0 ? current -= 1 : current = slides.length -1;
    showSlides(current);
}
function nextSlide () {
    //current가 이미지 마지막 인덱스 보다 작으면 다음 인덱스로 아니면 첫 이미지로 설정
    current < slides.length -1 ? current += 1 : current = 0;
    showSlides(current);
}