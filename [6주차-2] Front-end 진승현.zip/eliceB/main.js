const inputIcon = document.querySelector('.material-icons');
const searchInput = document.querySelector('#search-input');

inputIcon.addEventListener('click', () => {
    searchInput.focus();
})